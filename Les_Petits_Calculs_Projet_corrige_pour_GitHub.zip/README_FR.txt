LES PETITS CALCULS — PROJET ANDROID

Le jeu HTML original a été placé dans app/src/main/assets/index.html.
L'application Android l'ouvre dans une WebView locale : aucune connexion Internet
n'est nécessaire pour jouer. Le JavaScript et le stockage local sont activés afin
que le score en étoiles puisse être conservé sur l'appareil.

POUR CONSTRUIRE L'APK

Option ordinateur (Android Studio) :
1. Décompresser le ZIP.
2. Ouvrir le dossier Les_Petits_Calculs_Android dans Android Studio.
3. Laisser Gradle synchroniser et télécharger les composants demandés.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK de test sera dans app/build/outputs/apk/debug/app-debug.apk.

Option téléphone :
Il faut une application IDE Android capable d'ouvrir un projet Gradle Android
et les composants SDK/JDK. Les outils de compilation prennent plusieurs Go et
peuvent nécessiter une connexion Internet au premier lancement. AndroidIDE,
ancien outil souvent cité, a été archivé et n'est plus maintenu officiellement.

IMPORTANT
Ce ZIP est le projet source Android, pas encore un fichier APK installable.
Il n'a pas été compilé ni testé sur un appareil dans cet environnement.
